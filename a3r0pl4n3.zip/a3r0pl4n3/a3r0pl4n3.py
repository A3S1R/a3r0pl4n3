import dns.resolver
import sys

print "="*15 + "A3R0PL4N3 DNS TOOL" + "="*15
print "="*15 + "    by: A3S1R     " + "="*15
try:
    dom = sys.argv[1]
    wor = sys.argv[2]
except:
    print "Invalid Arguments"
    print "USAGE::\n./a3r0pl4n3.py <domain> <wordlist>"
    sys.exit()

try:
    arq = open(wor)
    rea = arq.read().splitlines()
except:
    print("Wordlist ERROR")
    sys.exit()

for sub in rea:
    try:
        sud = sub + "." + dom
        req = dns.resolver.query(sud, "a")
        for result in req:
            print sud, "===>", result
    except:
        pass
print "="*48
